"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Sparkles, Shield, Coins } from "lucide-react"

export default function Home() {
  const [isConnected, setIsConnected] = useState(false)

  const connectWallet = async () => {
    // Simulate wallet connection
    setIsConnected(true)
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-red-50">
      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center px-6 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <h1 className="text-6xl font-bold text-pink-900 mb-4">MetaLove Vault</h1>
          <p className="text-xl text-pink-700 max-w-2xl mx-auto leading-relaxed">
            Your love story, stored on-chain forever. Mint your romance as an NFT and celebrate your journey with
            AI-powered memories.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="mb-12"
        >
          {!isConnected ? (
            <Button
              onClick={connectWallet}
              size="lg"
              className="bg-pink-600 hover:bg-pink-700 text-white px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
            >
              <Heart className="mr-2 h-5 w-5" />
              Connect Wallet & Start Your Journey
            </Button>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-2 text-green-600 font-semibold">
                <Shield className="h-5 w-5" />
                Wallet Connected
              </div>
              <Button
                size="lg"
                className="bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Sparkles className="mr-2 h-5 w-5" />
                Create Your Love Story
              </Button>
            </div>
          )}
        </motion.div>
      </div>

      {/* Features Section */}
      <div className="px-6 py-16 max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-4xl font-bold text-center text-pink-900 mb-12"
        >
          How It Works
        </motion.h2>

        <div className="grid md:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
          >
            <Card className="border-pink-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="text-center">
                <div className="mx-auto w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mb-4">
                  <Sparkles className="h-8 w-8 text-pink-600" />
                </div>
                <CardTitle className="text-pink-900">AI Love Story</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center text-pink-700">
                  Our AI crafts a beautiful narrative from your memories, creating a unique love story that captures
                  your journey together.
                </CardDescription>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.6 }}
          >
            <Card className="border-pink-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="text-center">
                <div className="mx-auto w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mb-4">
                  <Heart className="h-8 w-8 text-pink-600" />
                </div>
                <CardTitle className="text-pink-900">Custom Portraits</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center text-pink-700">
                  Transform your photos into stunning anime, fantasy, or watercolor portraits that represent your unique
                  bond.
                </CardDescription>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.6 }}
          >
            <Card className="border-pink-200 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="text-center">
                <div className="mx-auto w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mb-4">
                  <Shield className="h-8 w-8 text-pink-600" />
                </div>
                <CardTitle className="text-pink-900">Blockchain Forever</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center text-pink-700">
                  Your love story becomes an eternal NFT on the blockchain, timestamped and preserved for generations to
                  come.
                </CardDescription>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* Gamification Preview */}
      <div className="px-6 py-16 bg-gradient-to-r from-pink-100 to-rose-100">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.6 }}
            className="text-4xl font-bold text-pink-900 mb-8"
          >
            Earn HEART Tokens
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.0, duration: 0.6 }}
            className="text-xl text-pink-700 mb-8 max-w-2xl mx-auto"
          >
            Complete love milestones, take AI quizzes, and celebrate anniversaries to earn HEART tokens and unlock
            special NFT rewards.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 1.1, duration: 0.6 }}
            className="flex items-center justify-center gap-2 text-2xl font-bold text-pink-800"
          >
            <Coins className="h-8 w-8 text-yellow-500" />
            <span>HEART</span>
          </motion.div>
        </div>
      </div>

      {/* Footer */}
      <footer className="px-6 py-8 text-center text-pink-600">
        <p>&copy; 2024 MetaLove Vault. Love stories that last forever.</p>
      </footer>
    </main>
  )
}
