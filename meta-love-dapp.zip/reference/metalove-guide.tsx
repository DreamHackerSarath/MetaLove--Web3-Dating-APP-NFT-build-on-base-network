🚀 Startup Idea Generator: AI + Crypto + Fun = $$$

Name: MetaLove Vault
Tagline: “Your love story, stored on-chain forever.”

🔐 What is it?

An AI-powered app where couples mint their love story as an NFT — powered by Ethereum or Solana — timestamped and sealed forever. Includes:

AI-generated love story from chat logs or prompts

Couple’s portraits turned into anime/fantasy art

Blockchain-verified “Anniversary Alerts”
\
Earn $HEART tokens
for milestones (like birthdays, messages, etc.)
\
🧩 Gamified
Features:
\
\
AI love quizzes that earn XP

NFT mystery boxes on Valentine’s Day

Breakup? Use a “Smart Separation Contract” that auto-burns the NFT ❤️‍🔥

Would you build this? Or want a twist like turning this into a dating app
with Web3 tokens? 😄
\
Want
another
surprise? Meme, quote, business, romantic
— you name it.

You said:
Sure build everything one by one 
ChatGPT said:

Awesome, Sarath. Let\'s start building MetaLove Vault — your AI x Blockchain romantic SaaS project — step by step.

✅ Step 1: Define the Full Product Scope

We'll break this into modules. Here's a Phase 1 scope to begin:

💖 MetaLove Vault – Phase 1 Scope
1. Landing Page + Onboarding

Love-themed homepage
with animation

“Mint Your Love Story” CTA
\
Connect Wallet (MetaMask, Coinbase, WalletConnect)

Sign-in
with Google/Apple (for non-crypto users)
\
2. AI Love Story Generator

Input: prompts / questions / messages

Output: AI-generated romantic story

Option to regenerate or edit manually

3. AI Portrait Generator

Upload couple photos

Choose style: Anime, Disney, Fantasy, Classic

AI generates stylized couple art

4. NFT Minting on Blockchain

Mint the story + art as an NFT

Choose chain: Ethereum, Polygon, Solana

Smart contract
with metadata storage (love story + image)
\
Display minting status and transaction link

5. Profile & Anniversary Reminder

Store anniversary/birthday data

Email/Web3 push reminder (via Push Protocol or Notifi)

Track relationship milestones (XP system)

6. Rewards & Referrals

$HEART token
for using features

Referral system with leaderboard
\
On-chain or backend reward logic\
\
🔧 Step 2: Tools & Stack
Layer	Stack / Tech
Frontend	Next.js + Tailwind + Framer
AI	OpenAI API, Stability AI
Auth	Web3Auth / Firebase
Blockchain	Solidity (ETH/Polygon), Metaplex (Solana)
Storage	IPFS / NFT.storage
Backend	Node.js + MongoDB
Deployment	Vercel + Thirdweb SDK + Alchemy

Next Steps:

➡️ Let me know:

Which blockchain to start
with (Ethereum / Polygon / Solana)
?
\
Do you want to use your own token ($HEART) from the beginning?

Ready to start
with the UI
landing
page
first?
\
Once
confirmed, we
’ll start building the frontend page
with connect wallet + AI
prompt
UI.Shall
I
begin?

You said
:\
Sure \
ChatGPT said:\
\
Perfect. Let\'s begin building MetaLove Vault step-by-step.
\
🧱 Step 1: UI Wireframe & Frontend - Landing Page + Wallet Connect
🎯 Goal

Build the frontend
for the homepage with
:

Romantic-themed UI

"Mint your Love Story\" CTA\
\
Connect Wallet (MetaMask, Coinbase, WalletConnect)

💡 Prompt to Build the Landing Page UI (
for Vercel or Local)
npx
create - next - app
@latest
metalove - vault
\
cd metalove-vault\
npm install wagmi viem
@rainbow
;-me / rainbowkit
ethers
\
🧩 Code Snippet – app/page.tsx (Romantic Hero Section + Wallet Connect)
"use client"

import { ConnectButton } from "@rainbow-me/rainbowkit"
import { motion } from "framer-motion"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-[#ffe4ec] to-[#fff0f5] text-[#4B0049] flex flex-col items-center justify-center px-6 py-12">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-5xl font-bold text-center"
      >
        💖 MetaLove Vault
      </motion.h1>
      <p className="mt-4 text-center text-lg max-w-xl">
        Mint your love story as a permanent NFT on-chain. Celebrate love, forever.
      </p>
      <motion.div className="mt-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
        <ConnectButton />
      </motion.div>
    </main>
  )
}

⚙️ Wallet Connect Setup (Next.js 13+
with App Router
)
\
Add the RainbowKit Provider in app/layout.tsx or wrap
with layout wrapper:

import "@rainbow-me/rainbowkit/styles.css";
\
import { getDefaultWallets, RainbowKitProvider } from "@rainbow-me/rainbowkit"
import { WagmiConfig, createConfig, configureChains } from "wagmi"
import { mainnet, polygon } from "wagmi/chains"
import { publicProvider } from "wagmi/providers/public"

const { chains, publicClient } = configureChains([mainnet, polygon, base], [publicProvider()])

const { connectors } = getDefaultWallets({
  appName: "MetaLove Vault",
  projectId: "YOUR_WALLETCONNECT_PROJECT_ID",
  chains,
})

const config = createConfig({
  autoConnect: true,
  connectors,
  publicClient,
})

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <WagmiConfig config={config}>
          <RainbowKitProvider chains={chains}>
            {children}
          </RainbowKitProvider>
        </WagmiConfig>
      </body>
    </html>
  );
}

🎨 Styling

Use Tailwind
for elegant styling. Romantic color palette:

Background: #ffe4ec, #fff0f5
\
Text: #4B0049, #8B5E83
\
Button Hover: #ff69b4

✅ What’s Ready After This?

Romantic homepage
with brand

Web3
wallet
integration(Ethereum, Polygon, Base)

Ready
for user to proceed to
the
AI
Story
or
Minting
flow

🚀 Next Step?

Shall we now build:

AI-powered Love Story Generator (Next.js + OpenAI)

or NFT Minting Flow (Solidity or Thirdweb)

or Portrait AI image gen (Stability or Replicate API)?

You choose the next step — I’ll build it fully.

You said:
Next 
ChatGPT said:

Great. Let’s move to the next feature
for MetaLove Vault
:

💌 Step 2: AI-Powered Love Story Generator (Next.js + OpenAI)
🎯 Goal:

Let couples enter details about their relationship and generate a beautiful romantic story
using OpenAI
.

🧠 Inputs from Users:

Name 1 and Name 2

How they met

Favorite memory

First date location

Any funny or emotional moment

Relationship milestone (e.g. anniversary)

🛠️ Tech:

Frontend: Next.js form UI

Backend/API: OpenAI GPT-4 API

Storage (optional): Local state or Firebase/Mongo (
for saving drafts)

🧩 Frontend Code – app/story/page.tsx
'use client'

import { useState } from "react"

export default function LoveStory() {
  const [form, setForm] = useState({
    name1: "",
    name2: "",
    howMet: "",
    memory: "",
    datePlace: "",
    moment: "",
    milestone: ""
  });

  const [story, setStory] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const generateStory = async () => {
    setLoading(true);
    const res = await fetch("/api/generate-story", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setStory(data.story);
    setLoading(false);
  };

  return (
    <div className="max-w-xl mx-auto px-6 py-10 bg-white rounded-xl shadow-md">
      <h2 className="text-2xl font-bold text-pink-700 mb-4">💖 Generate Your Love Story</h2>
      {["name1", "name2", "howMet", "memory", "datePlace", "moment", "milestone"].map((field) => (
        <input
          key={field}
          name={field}
          placeholder={field}
          value={form[field]}
          onChange={handleChange}
          className="w-full mb-4 px-4 py-2 border rounded-md"
        />
      ))}
      <button
        onClick={generateStory}
        className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-md w-full"
        disabled={loading}
      >
        {loading ? "Crafting Story..." : "Generate Story"}
      </button>
      {story && (
        <div className="mt-6 p-4 bg-pink-50 border-l-4 border-pink-400 text-pink-800 rounded-md">
          <h3 className="font-bold mb-2">💌 Your Story:</h3>
          <p>{story}</p>
        </div>
      )}
    </div>
  );
}

🌐 Backend API – /app/api/generate-story/route.ts
import { type NextRequest, NextResponse } from "next/server"
import { OpenAI } from "openai"

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: NextRequest) {
  const body = await req.json()

  const prompt = `
Write a sweet romantic love story about ${body.name1} and ${body.name2}.
They met like this: ${body.howMet}.
Their favorite memory together: ${body.memory}.
Their first date happened at: ${body.datePlace}.
A funny or emotional moment: ${body.moment}.
Their milestone: ${body.milestone}.

Make it heartwarming, cinematic, and memorable.
`

  const completion = await openai.chat.completions.create({
    messages: [{ role: "user", content: prompt }],
    model: "gpt-4",
    temperature: 0.9,
  })

  const story = completion.choices[0].message.content
  return NextResponse.json({ story })
}

✅ Result:

Users will now be able to:

Fill in personal romantic details

Instantly receive a GPT-generated love story

(Later: Mint it as an NFT!)

🔜 Next Options – What
do you want
next?

🎨 AI
Portrait
Generator (Upload couple photos → Anime/Disney art via Stability API)

⛓️ NFT Minting (Turn AI love story + image into an NFT)

🪙 Reward System (Add $HEART token
for usage and referrals)

Pick
one
— I’ll build it completely.

You said:
Build one by one 
ChatGPT said:

Awesome,
let
's continue step by step.

🎨 Step 3: AI Portrait Generator – Turn Couple Photos into Stylized Art
🎯 Goal:

Allow users to upload photos → Choose a style → Get a stylized couple portrait (Anime / Disney / Fantasy / Watercolor etc.)

🛠️ Tools & Stack
Feature	Tool/Platform
Image Upload	Next.js + Firebase Storage
AI Image Generation	Stability AI (via Replicate API) or HuggingFace
Stylization Model	animegan, toonify, or portrait-plus models
Optional Storage	IPFS (
for NFT minting later)
📥 Frontend: Upload + Choose Style

File: app/portrait/page.tsx

'use client'

import { useState } from "react"

export default function PortraitGenerator() {
  const [image, setImage] = useState(null);
  const [style, setStyle] = useState('anime');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleUpload = async (e: any) => {
    const file = e.target.files[0];
    setImage(file);
  };

  const generate = async () => {
    if (!image) return;
    setLoading(true);
    const formData = new FormData();
    formData.append('file', image);
    formData.append('style', style);

    const res = await fetch('/api/generate-portrait', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    setResult(data.output);
    setLoading(false);
  };

  return (
    <div className="max-w-xl mx-auto py-10 px-4">
      <h2 className="text-3xl font-bold text-pink-700 mb-4">🖼️ AI Couple Portrait</h2>
      <input type="file" onChange={handleUpload} className="mb-4" />
      <select onChange={(e) => setStyle(e.target.value)} className="mb-4 p-2 rounded">
        <option value="anime">Anime</option>
        <option value="disney">Disney</option>
        <option value="fantasy">Fantasy</option>
        <option value="watercolor">Watercolor</option>
      </select>
      <button onClick={generate} className="bg-pink-600 text-white px-6 py-2 rounded-md">
        {loading ? 'Generating...' : 'Generate Portrait'}
      </button>

      {result && (
        <div className="mt-6">
          <h3 className="text-pink-700 font-bold mb-2">✨ Output:</h3>
          <img src={result} alt="AI Portrait" className="rounded-lg shadow-lg" />
        </div>
      )}
    </div>
  );
}

🌐 Backend API – /api/generate-portrait/route.ts

This uses Replicate
for AI image generation (AnimeGAN or equivalent)
:

import { type NextRequest, NextResponse } from "next/server"
import Replicate from "replicate"

export const config = { api: { bodyParser: false } }

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN!,
})

export async function POST(req: NextRequest) {
  const data = await req.formData()
  const file = data.get("file") as File
  const style = data.get("style") as string

  const bytes = await file.arrayBuffer()
  const buffer = Buffer.from(bytes)

  // Upload image to external storage or Replicate URL
  const imageBase64 = buffer.toString("base64")
  const inputImage = `data:image/png;base64,${imageBase64}`

  const output = await replicate.run(
    `stability-ai/${style}-portrait-model`, // Replace with model slug
    {
      input: { image: inputImage },
    },
  )

  return NextResponse.json({ output })
}

✅ Result:

Users can now:

Upload their couple photo

Choose from 4 styles (Anime, Disney, etc.)

Instantly see a stylized version

(Next: Save to IPFS + Mint)

🔜 Next Step:

Shall we
continue to
:

Minting the AI Love Story + Portrait as NFT

Add Couple Profile + Anniversary Tracker

Add Referral + Reward
with $HEART Token

Type: Next
— and I’ll build the next feature completely.

You said:
Build one by one 
ChatGPT said:

Great,
let
’s move forward step-by-step.

🔗 Step 4: NFT Minting – Mint AI Love Story + Portrait as an NFT
🎯 Goal:

Enable users to mint their AI-generated love story + AI portrait as an NFT on-chain (Ethereum, Polygon, or Base).

🧱 Minting Options

We’ll use Thirdweb SDK to simplify the smart contract + frontend minting process.

Feature	Tool / Stack
Smart Contract	ERC-721 via Thirdweb
Storage (story + image)	IPFS via Thirdweb
Blockchain	Polygon or Base
Frontend	Next.js
✅ NFT Metadata Format
{
  ;("name")
  : "Love Story of A & B",
  "description": "A beautiful love story minted as an NFT with their AI-generated portrait.",
  "image": "<portrait image url>",
  "attributes": [
  ;("trait_type")
  : "Anniversary", "value": "Feb 14, 2021"
  ,
  ;("trait_type")
  : "Location", "value": "Paris"
  ]
}

🔧 Step-by-Step Setup
1. Install Thirdweb SDK
npm install
@thirdweb
;-dev / react
@thirdweb
;-dev / sdk
ethers

2
Configure
Wallet + SDK

app / layout.tsx

import { ThirdwebProvider } from "@thirdweb-dev/react"
import { BaseGoerli } from "@thirdweb-dev/chains" // or use Polygon

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <ThirdwebProvider
          activeChain={BaseGoerli}
          clientId={process.env.NEXT_PUBLIC_THIRDWEB_CLIENT_ID}
        >
          {children}
        </ThirdwebProvider>
      </body>
    </html>
  );
}

3
Frontend
Mint
UI

app / mint / page.tsx
;("use client")

import { useState } from "react"
import { useAddress, useContract, useMintNFT } from "@thirdweb-dev/react"

export default function MintLoveStory() {
  const address = useAddress();
  const { contract } = useContract("YOUR_CONTRACT_ADDRESS");
  const { mutateAsync: mintNft, isLoading } = useMintNFT(contract);

  const [story, setStory] = useState("Once upon a time...");
  const [image, setImage] = useState(null);

  const handleMint = async () => {
    const metadata = {
      name: "Our Love Story",
      description: story,
      image, // File or URL
    };

    try {
      const tx = await mintNft({ to: address, metadata });
      alert("Minted! Tx Hash: " + tx.id);
    } catch (e) {
      console.error(e);
      alert("Minting failed.");
    }
  };

  return (
    <div className="max-w-xl mx-auto py-10 px-4">
      <h2 className="text-3xl font-bold text-pink-700 mb-4">💍 Mint Your Love NFT</h2>
      <textarea
        className="w-full p-4 mb-4 border rounded"
        rows={5}
        value={story}
        onChange={(e) => setStory(e.target.value)}
      />
      <input type="file" onChange={(e) => setImage(e.target.files[0])} className="mb-4" />
      <button onClick={handleMint} disabled={isLoading} className="bg-pink-600 text-white px-6 py-2 rounded-md">
        {isLoading ? "Minting..." : "Mint NFT"}
      </button>
    </div>
  );
}

📦 Deploy Smart Contract

Use thirdweb.com dashboard:

Choose ERC-721 Drop or NFT Collection

Set name: MetaLove Vault

Upload default metadata (optional)

Deploy on Base, Polygon, or testnets

Copy contract address and use it in the code above.

✅ Result:

Users can:

See their AI-generated love story + portrait

Mint as NFT on-chain

Link to transaction and view on explorer

🔜 Next Step

Now that minting is done,
let
’s build:

❤️ Couple Profile + Anniversary Tracker

💸 $HEART Token Rewards + Referrals System

📊 On-chain Leaderboard (Top Lovers)

Type Next to build the next
module.You
said: Next
ChatGPT
said: Thought
for 6s

Perfect—moving
on.

❤️ Step 5: Couple Profiles + Anniversary Tracker (
with reminders)
Goal

Store
couple
profiles (names, wallets, dates, links to NFT).

Calculate
“days to next anniversary”.

Optional reminders via email or Web3 push.

1) Data Model (MongoDB + Mongoose)

Install & setup

npm i mongoose


lib/db.ts

import mongoose from "mongoose"

const MONGODB_URI = process.env.MONGODB_URI!
if (!MONGODB_URI) throw new Error("Missing MONGODB_URI")

const cached = (global as any).mongoose || { conn: null, promise: null }
export default async function dbConnect() {
  if (cached.conn) return cached.conn;
  if (!cached.promise) {
    cached.promise = mongoose.connect(MONGODB_URI).then((m) => m);
  }
  cached.conn = await cached.promise;
  return cached.conn;
}

models / Couple.ts

const CoupleSchema = new Schema(
  {
    wallet: { type: String, index: true },
    email: { type: String },
    name1: String,
    name2: String,
    anniversaryISO: { type: String, required: true }, // "YYYY-MM-DD"
    birthday1ISO: String,
    birthday2ISO: String,
    storyCid: String, // IPFS CID for story (optional)
    imageCid: String, // IPFS CID for portrait (optional)
    chainId: Number,
    contract: String,
    tokenId: String,
    xp: { type: Number, default: 0 },
    referralCode: { type: String, unique: true, sparse: true },
    referredBy: String,
  },
  { timestamps: true },
)

export default models.Couple || mongoose.model("Couple", CoupleSchema);

2
) API Routes

Create/Update profile — app/api/profile/route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Couple from "@/models/Couple"

export async function POST(req: NextRequest) {
  await dbConnect()
  const body = await req.json()
  const { wallet, ...rest } = body

  if (!wallet) return NextResponse.json({ error: "wallet required" }, { status: 400 })

  const doc = await Couple.findOneAndUpdate(
    { wallet: wallet.toLowerCase() },
    { wallet: wallet.toLowerCase(), ...rest },
    { upsert: true, new: true },
  )

  return NextResponse.json({ ok: true, profile: doc })
}

export async function GET(req: NextRequest) {
  await dbConnect()
  const { searchParams } = new URL(req.url)
  const wallet = searchParams.get("wallet")?.toLowerCase()
  if (!wallet) return NextResponse.json({ error: "wallet required" }, { status: 400 })
  const doc = await Couple.findOne({ wallet })
  return NextResponse.json({ profile: doc })
}

Utility: days
to
next
anniversary
— app/api/anniversary/route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Couple from "@/models/Couple"

function daysUntilNext(dateISO: string) {
  const today = new Date()
  const [y, m, d] = dateISO.split("-").map(Number)
  const thisYear = new Date(today.getFullYear(), m - 1, d)
  const next = thisYear < today ? new Date(today.getFullYear() + 1, m - 1, d) : thisYear
  const diff = Math.ceil((+next - +new Date(today.toDateString())) / 86400000)
  return { days: diff, nextOn: next.toISOString().slice(0, 10) }
}

export async function GET(req: NextRequest) {
  await dbConnect()
  const { searchParams } = new URL(req.url)
  const wallet = searchParams.get("wallet")?.toLowerCase()
  if (!wallet) return NextResponse.json({ error: "wallet required" }, { status: 400 })

  const doc = await Couple.findOne({ wallet })
  if (!doc?.anniversaryISO) return NextResponse.json({ error: "no anniversary set" }, { status: 404 })

  const { days, nextOn } = daysUntilNext(doc.anniversaryISO)
  return NextResponse.json({ days, nextOn, anniversaryISO: doc.anniversaryISO })
}

3
) Frontend Pages

Profile form — app/profile/page.tsx

'use client'

import { useEffect, useState } from "react"
import { useAccount } from "wagmi"

export default function ProfilePage() {
  const { address } = useAccount();
  const [form, setForm] = useState({
    name1: "", name2: "",
    anniversaryISO: "", birthday1ISO: "", birthday2ISO: "",
    email: ""
  });
  const [loading, setLoading] = useState(false);
  const [daysLeft, setDaysLeft] = useState<number | null>(null);
  const [nextOn, setNextOn] = useState<string | null>(null);

  useEffect(() => {
    if (!address) return;
    (async () => {
      const res = await fetch(`/api/profile?wallet=${address}`);
      const data = await res.json();
      if (data?.profile) setForm((f) => ({ ...f, ...data.profile }));
      const a = await fetch(`/api/anniversary?wallet=${address}`);
      const b = await a.json();
      if (b?.days !== undefined) { setDaysLeft(b.days); setNextOn(b.nextOn); }
    })();
  }, [address]);

  const save = async () => {
    setLoading(true);
    await fetch("/api/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ wallet: address, ...form }),
    });
    setLoading(false);
    alert("Saved!");
  };

  const onChange = (e: any) => setForm({ ...form, [e.target.name]: e.target.value });

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow">
      <h1 className="text-3xl font-bold text-pink-700">💖 Couple Profile</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
        <input className="border p-3 rounded" placeholder="Partner 1 name" name="name1" value={form.name1} onChange={onChange} />
        <input className="border p-3 rounded" placeholder="Partner 2 name" name="name2" value={form.name2} onChange={onChange} />
        <input className="border p-3 rounded" type="date" name="anniversaryISO" value={form.anniversaryISO?.slice(0,10) || ""} onChange={onChange} />
        <input className="border p-3 rounded" type="date" name="birthday1ISO" value={form.birthday1ISO?.slice(0,10) || ""} onChange={onChange} />
        <input className="border p-3 rounded" type="date" name="birthday2ISO" value={form.birthday2ISO?.slice(0,10) || ""} onChange={onChange} />
        <input className="border p-3 rounded" type="email" placeholder="Email (for reminders)" name="email" value={form.email || ""} onChange={onChange} />
      </div>

      <button onClick={save} disabled={loading} className="mt-6 bg-pink-600 hover:bg-pink-700 text-white px-6 py-3 rounded-lg">
        {loading ? "Saving..." : "Save Profile"}
      </button>

      {daysLeft !== null && (
        <div className="mt-6 p-4 bg-pink-50 border-l-4 border-pink-400 rounded">
          <div className="font-semibold">🎉 Next Anniversary: <span className="underline">{nextOn}</span></div>
          <div>{daysLeft === 0 ? "Today is the day! 💍" : `${daysLeft} day(s) left`}</div>
        </div>
      )}
    </div>
  );
}

4
) Optional: Reminders (Email or Web3 Push)

Pick either (or both):

A) Email (Resend) + Vercel Cron

npm i resend

Add RESEND_API_KEY in .env.

Create app/api/cron/send-reminders/route.ts that:

Finds profiles where daysUntilNext(anniversaryISO) ∈
{
  14, 7, 3, 1, 0
}

Sends
a
lovely
reminder
email.Add
a
Vercel
cron
job (e.g., daily at 09:00 IST)
hitting / api / cron / send - reminders.B
) Web3 Push (Push Protocol / EPNS)

Create a channel and send notifications to wallet addresses a week/day before the date.

(If you want, I’ll drop the ready-to-run cron/email route next.)

5) UX touches

Show a progress ring (XP) toward next milestone.

Badge: “1-Year Strong”, “5K Days Together”, etc.

CTA on profile: “Mint Anniversary Update” → new NFT edition or metadata update.

6) Environment variables
MONGODB_URI="mongodb+srv://..."
NEXT_PUBLIC_THIRDWEB_CLIENT_ID="..."
RESEND_API_KEY="..."                    #
if using email
PUSH_PRIVATE_KEY = "0x..."
#
if using Push
Protocol

✅ What you now have

Persistent couple profiles tied to wallet.

Days-until-next-anniversary calculation + UI.

Hooks to add email/Web3 reminders.

Next choices:

💸 $HEART Rewards + Referral System (on-chain or backend ledger)

📊 On-chain Leaderboard (top referrers / minters / streaks)

🧾 Checkout / Paywall (gate certain features
with NFT/fee)

Reply
“Next” and tell me which one to build next (or I’ll proceed
with $HEART rewards + referrals
by
default).

You said:
Next 
ChatGPT said:
Thought
for 18s

Awesome — time
to
wire in rewards + referrals.

💸 Step 6: $HEART Rewards + Referrals (on-chain claims, off-chain tracking)
What you get

An ERC-20 token $HEART (mintable).

A Rewarder contract where users claim rewards
with a backend
signature (no trust in server minting directly).

Referral
codes (?ref=0x...) + one-time
credit
for referrer & referred.

Mongo-backed leaderboard.

1) Smart
Contracts(Solidity)

A
) $HEART token

contracts/HeartToken.sol

// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20

import { ERC20 } from "@openzeppelin/contracts/token/ERC20/ERC20.sol"

contract
HeartToken
is
ERC20, AccessControl
{
  bytes32
  public
  constant
  MINTER_ROLE = keccak256("MINTER_ROLE")

  constructor(address admin)
  ERC20("MetaLove HEART", "HEART")
  _grantRole(DEFAULT_ADMIN_ROLE, admin)

  function mint(address to, uint256 amount)
  external
  onlyRole(MINTER_ROLE)
  _mint(to, amount)
}

B
) Rewarder (signed voucher → mints HEART)

contracts/Rewarder.sol

// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20

import { HeartToken } from "./HeartToken.sol"

contract
Rewarder
{
  HeartToken
  public
  immutable
  heart
  address
  public
  signer // backend EOA that signs vouchers
  mapping((bytes32) => bool)
  public
  used // nonces

  event
  Claimed(address indexed to, uint256 amount, bytes32 nonce);

  constructor(address heartToken, address initialSigner)
  heart = HeartToken(heartToken)
  signer = initialSigner

  function setSigner(address s)
  external
  require(msg.sender == heart.getRoleMember(0x00, 0), "only admin") // DEFAULT_ADMIN of HEART
  signer = s

  // EIP-191 style message:
  // keccak256("CLAIM(address to,uint256 amount,bytes32 nonce,address rewarder)")
  // packed as abi.encodePacked
  function claim(address to, uint256 amount, bytes32 nonce, bytes calldata sig)
  external
  require(!used[nonce], "nonce used")
  bytes32
  digest = keccak256(
      abi.encodePacked(
        "\x19Ethereum Signed Message:\n32",
        keccak256(abi.encodePacked("CLAIM(", to, amount, nonce, address(this), ")")),
      ),
    )
    (bytes32
    r, bytes32
    s, uint8
    v
    ) = _splitSig(sig)
  address
  recovered = ecrecover(digest, v, r, s)
  require(recovered == signer, "bad signature")
  used[nonce] = true
  heart.mint(to, amount)
  emit
  Claimed(to, amount, nonce)

  function _splitSig(bytes memory sig)
  internal
  pure
  returns (bytes32 r, bytes32 s, uint8 v)
  require(sig.length == 65, "bad sig length")
  assembly
  r :
  = mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
}

Deploy
flow

Deploy
HeartToken(admin=your EOA).

Deploy
Rewarder(heartAddr, backendSigner).From
admin, grant
minter: heart.grantRole(MINTER_ROLE, rewarderAddr).Tip
: Use Base or Polygon to keep gas low.

2) Referral Tracking (Mongo) + Voucher Issuance (Backend)

Model

models/Reward.ts
const RewardSchema = new Schema(
  {
    wallet: { type: String, index: true },
    type: { type: String, enum: ["signup", "mint", "referrer", "referred", "anniversary"], index: true },
    amount: { type: String, required: true }, // in wei string
    nonce: { type: String, unique: true, index: true },
    claimed: { type: Boolean, default: false },
  },
  { timestamps: true },
)

export default models.Reward || mongoose.model("Reward", RewardSchema);

models / Referral.ts
const ReferralSchema = new Schema(
  {
    referred: { type: String, unique: true, index: true }, // wallet
    referrer: { type: String, index: true },
  },
  { timestamps: true },
)

export default models.Referral || mongoose.model("Referral", ReferralSchema);

Attach
referral
on
first
session

When
user
lands
on
any
page, capture ?ref=0xReferrer.

On first
profile
save
or
first
connect, POST
to / api / referral / attach.app / api / referral / attach / route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Referral from "@/models/Referral"
import Reward from "@/models/Reward"
import { randomBytes } from "crypto"

const REFERRER_REWARD = parseEther("5").toString() // 5 HEART
const REFERRED_REWARD = parseEther("5").toString() // 5 HEART

export async function POST(req: NextRequest) {
  await dbConnect()
  const { referred, referrer } = await req.json()
  if (!referred || !referrer) return NextResponse.json({ error: "missing" }, { status: 400 })
  if (referred.toLowerCase() === referrer.toLowerCase()) {
    return NextResponse.json({ error: "self-referral not allowed" }, { status: 400 })
  }

  const exists = await Referral.findOne({ referred: referred.toLowerCase() })
  if (exists) return NextResponse.json({ ok: true, already: true })

  await Referral.create({ referred: referred.toLowerCase(), referrer: referrer.toLowerCase() })

  // create reward vouchers (unclaimed yet)
  const nonceA = "referrer-" + randomBytes(16).toString("hex")
  const nonceB = "referred-" + randomBytes(16).toString("hex")

  await Reward.create({ wallet: referrer.toLowerCase(), type: "referrer", amount: REFERRER_REWARD, nonce: nonceA })
  await Reward.create({ wallet: referred.toLowerCase(), type: "referred", amount: REFERRED_REWARD, nonce: nonceB })

  return NextResponse.json({ ok: true })
}

Sign
vouchers
endpoint

Your
backend
holds
BACKEND_SIGNER_PK
to
sign
claim
payloads
that
users
submit
on - chain
to
Rewarder.claim.lib / sign.ts

import { encodePacked, keccak256, toBytes, privateKeyToAccount } from "viem"
import { base } from "viem/chains"

const account = privateKeyToAccount(process.env.BACKEND_SIGNER_PK as `0x${string}`)
export async function signClaim({
  to,
  amount,
  nonce,
  rewarder,
}: { to: `0x${string}`; amount: bigint; nonce: string; rewarder: `0x${string}` }) {
  // message = keccak256(abi.encodePacked("CLAIM(", to, amount, nonce, rewarder, ")"))
  const inner = keccak256(
    encodePacked(["string", "address", "uint256", "string", "address"], ["CLAIM(", to, amount, nonce, rewarder]),
  )
  const digest = keccak256(encodePacked(["string", "bytes32"], ["\x19Ethereum Signed Message:\n32", inner]))
  // EOA personal_sign can directly sign the inner hash (or use account.signMessage)
  const signature = await account.signMessage({ message: { raw: toBytes(inner) } })
  return signature as `0x${string}`
}

app / api / rewards / voucher / route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Reward from "@/models/Reward"
import { signClaim } from "@/lib/sign"

const REWARDER_ADDRESS = process.env.REWARDER_ADDRESS as `0x${string}`

export async function POST(req: NextRequest) {
  await dbConnect()
  const { wallet } = await req.json()
  if (!wallet) return NextResponse.json({ error: "wallet required" }, { status: 400 })

  // find one unclaimed reward for this wallet
  const reward = await Reward.findOne({ wallet: wallet.toLowerCase(), claimed: false }).sort({ createdAt: 1 })
  if (!reward) return NextResponse.json({ ok: true, none: true })

  const sig = await signClaim({
    to: wallet,
    amount: BigInt(reward.amount),
    nonce: reward.nonce,
    rewarder: REWARDER_ADDRESS,
  })

  return NextResponse.json({
    voucher: {
      to: wallet,
      amount: reward.amount,
      nonce: reward.nonce,
      signature: sig,
      rewarder: REWARDER_ADDRESS,
    },
  })
}

Mark as claimed
(idempotent
webhook - ish
)

app/api/rewards/claimed/route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Reward from "@/models/Reward"

export async function POST(req: NextRequest) {
  await dbConnect()
  const { nonce } = await req.json()
  if (!nonce) return NextResponse.json({ error: "nonce required" }, { status: 400 })
  await Reward.updateOne({ nonce }, { $set: { claimed: true } })
  return NextResponse.json({ ok: true })
}

3
) Frontend: Referral capture + Claim UI

Capture ?ref= once (e.g., in app/layout.tsx)

'use client'
import { useEffect } from "react"
import { useAccount } from "wagmi"

export default function Layout({ children }: { children: React.ReactNode }) {
  const { address } = useAccount();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref && address) {
      fetch("/api/referral/attach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ referred: address, referrer: ref }),
      }).catch(()=>{});
    }
  }, [address]);

  return <>{children}</>;
}

Claim
button
page
— app/rewards/page.tsx

'use client'
import { useState } from "react"
import { useAccount, useWalletClient } from "wagmi"
import { ethers } from "ethers"

export default function RewardsPage() {
  const { address } = useAccount();
  const { data: walletClient } = useWalletClient();
  const [status, setStatus] = useState("");

  const claim = async () => {
    setStatus("Checking voucher...");
    const res = await fetch("/api/rewards/voucher", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ wallet: address }),
    });
    const data = await res.json();
    if (data?.none) return setStatus("No rewards to claim yet.");

    const { voucher } = data;
    setStatus("Sending on-chain claim...");

    const provider = new ethers.BrowserProvider((walletClient as any)?.transport?.walletClient || (window as any).ethereum);
    const signer = await provider.getSigner();
    const rewarder = new ethers.Contract(
      voucher.rewarder,
      [
        "function claim(address to,uint256 amount,bytes32 nonce,bytes sig) external",
        "event Claimed(address indexed to,uint256 amount,bytes32 nonce)"
      ],
      signer
    );

    const nonceBytes32 = ethers.id(voucher.nonce); // hash string -> bytes32
    const tx = await rewarder.claim(address, voucher.amount, nonceBytes32, voucher.signature);
    await tx.wait();

    await fetch("/api/rewards/claimed", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nonce: voucher.nonce }) });

    setStatus("Claimed! 🎉");
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-2xl shadow">
      <h1 className="text-2xl font-bold text-pink-700">💸 Claim $HEART</h1>
      <p className="mt-2 text-sm text-gray-600">Get rewards for referrals, signups, mints, and milestones.</p>
      <button onClick={claim} className="mt-6 w-full bg-pink-600 text-white py-3 rounded-lg">Claim Rewards</button>
      <div className="mt-3 text-sm">{status}</div>
    </div>
  );
}

4
) Leaderboard (Mongo aggregate)

app/api/leaderboard/route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Reward from "@/models/Reward"

export async function GET(_: NextRequest) {
  await dbConnect()
  // Sum amounts per wallet (claimed only)
  const rows = await Reward.aggregate([
    { $match: { claimed: true } },
    { $group: { _id: "$wallet", total: { $sum: { $toDecimal: "$amount" } } } },
    { $sort: { total: -1 } },
    { $limit: 50 },
  ])
  // return as strings
  const data = rows.map((r) => ({ wallet: r._id, total: r.total.toString() }))
  return NextResponse.json({ data })
}

Frontend
widget (top 10)

;
;("use client")
import { useEffect, useState } from "react"

export function Leaderboard() {
  const [rows, setRows] = useState<any[]>([])
  useEffect(() => {
    fetch("/api/leaderboard")
      .then((r) => r.json())
      .then((d) => setRows(d.data || []))
  }, [])
  return (
    <div className="p-4 bg-white rounded-xl shadow">
      <h3 className="font-bold text-pink-700 mb-3">🏆 Top Lovers (by $HEART)</h3>
      <ol className="space-y-2">
        {rows.slice(0, 10).map((r, i) => (
          <li key={r.wallet} className="flex justify-between">
            <span>
              {i + 1}. {r.wallet.slice(0, 6)}…{r.wallet.slice(-4)}
            </span>
            <span>{r.total}</span>
          </li>
        ))}
      </ol>
    </div>
  )
}

5
) Reward Triggers (examples)

Decide amounts (in HEART):

Signup/profile completed → 5

First mint → 20

Each referral (referrer + referred) → 5

Anniversary check-in → 10

When an event happens (e.g., successful mint), your backend creates a Reward row (unclaimed)
for the user; the user
can
then
Claim
on - chain
anytime
using the
voucher
flow.

6
) Env vars
MONGODB_URI="..."
BACKEND_SIGNER_PK="0xYourPrivateKey"     # used only
for signing vouchers
REWARDER_ADDRESS="0x..."                 #
deployed
Rewarder

Security
note: The
backend
does
not
mint
directly
it
only
signs
vouchers.The
Rewarder
mints
after
verifying
the
signature
and
one - time
nonce.

✅ Done

Token + signed-claim reward system.

Referral attach + rewards.

Claim UI + Leaderboard.

Next step options:

🔒 Gate /deploy behind fee or holding a HEART/NFT

👀 Public Profiles & Feed (display minted stories, likes, comments)

📦 One-click “Gift Box” mint (Valentine/anniversary templates)

Reply Next and I’ll build the gate/paywall (fee or NFT) by default.

You said:
Next 
ChatGPT said:

Alright —
let
’s move to the access gate/paywall feature.

🔒 Step 7: Gate Access Behind NFT or Fee
Goal

Certain pages (like /deploy, special AI generators) should only be available to:

Users holding a specific NFT, OR

Users who pay a one-time fee in native gas token ($MATIC, $ETH, etc.).

1) NFT Gating (Holder Check)

We’ll reuse Thirdweb
for NFT balance checks.

Example
— wrapper HOC

'use client'
import { useAddress, useContract, useNFTBalance } from "@thirdweb-dev/react"
import { useRouter } from "next/navigation"

export function NFTGate({ children }: { children: React.ReactNode }) {
  const address = useAddress()
  const router = useRouter()
  const { contract } = useContract("0xYourNFTContractAddress")
  const { data: balance, isLoading } = useNFTBalance(contract, address, "0")

  if (isLoading) return <div>Checking access…</div>
  if (!address) return <div>Please connect wallet.</div>
  if (!balance || balance.toNumber() === 0) {
    return (
      <div>
        You need to own our Access NFT. <a href="/mint-access">Mint Now</a>
      </div>
    )
  }

  return <>{children}</>
}

Usage in a
gated
page

import { NFTGate } from "@/components/NFTGate"

export default function DeployPage() {
  return (
    <NFTGate>
      <h1>🚀 Deploy Love Story</h1>
      {/* Your deploy UI */}
    </NFTGate>
  );
}

2
) Fee Gating (Pay to Access)

We can require a transaction to a treasury wallet before granting access (tracked in DB).

Backend API — app/api/pay-access/route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import AccessPass from "@/models/AccessPass"

export async function POST(req: NextRequest) {
  await dbConnect()
  const { wallet, txHash } = await req.json()
  if (!wallet || !txHash) return NextResponse.json({ error: "missing" }, { status: 400 })

  // Optionally verify txHash on chain (Alchemy/ethers)
  await AccessPass.create({ wallet: wallet.toLowerCase(), txHash })

  return NextResponse.json({ ok: true })
}

Model
— models/AccessPass.ts
const AccessPassSchema = new Schema(
  {
    wallet: { type: String, index: true },
    txHash: String,
  },
  { timestamps: true },
)
export default models.AccessPass || mongoose.model("AccessPass", AccessPassSchema);

Frontend
payment
trigger
;("use client")
import { useAccount, useWalletClient } from "wagmi"
import { ethers } from "ethers"

export default function PaywallButton() {
  const { address } = useAccount();
  const { data: walletClient } = useWalletClient();

  const pay = async () => {
    const provider = new ethers.BrowserProvider((window as any).ethereum);
    const signer = await provider.getSigner();
    const tx = await signer.sendTransaction({
      to: "0xTreasuryWalletAddress",
      value: ethers.parseEther("0.001") // fee
    });
    await tx.wait();
    await fetch("/api/pay-access", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ wallet: address, txHash: tx.hash })
    });
    alert("Payment recorded, access granted!");
  };

  return (
    <button onClick={pay} className="bg-pink-600 text-white px-6 py-3 rounded-lg">
      Pay 0.001 ETH for Access
    </button>
  );
}

3
) Hybrid Gating Logic

Check AccessPass DB OR NFT balance.

Example combined check:

if (!nftHolder && !paidAccess) {
  return <div>Access Denied — please mint NFT or pay fee.</div>;
}

4
) Treasury Flow

Treasury wallet should be multisig
for safety (Gnosis Safe).

For gas token pricing (e.g., always ~$5), fetch
latest
USD
price
from
Coingecko
and
convert
to
chain
native
currency.

5
) UX Tips

Show countdown
for temporary passes (e.g., 30 days access).

Allow users to
upgrade
from
paid
pass
to
NFT
permanently.Offer
free
trial
for referred users.

✅ Result:
Now /deploy
or
any
premium
feature
is
locked
behind: NFT
ownership, or

One - time
on - chain
payment(recorded in backend).If
you
’re ready, next we can build public profiles + love story feed so couples can share & browse minted stories,
with likes/comments.

Do you
want
me
to
proceed
to
that
next?

You said
:
Sure 
ChatGPT said:

Alright —
let
's move to the Public Profiles + Love Story Feed so couples can share their minted stories and others can browse, like, and comment.

💕 Step 8: Public Profiles & Love Story Feed
🎯 Goal

Each couple has a public profile page
with
:

Names, anniversary date, portrait.

Minted NFTs
with story & metadata.

Social links (optional).

Global
feed
showing
all
minted
love
stories (public by default or opt-in).

Likes & comments
on
each
story (on-chain optional, but we’ll start off-chain for speed).

1
) Data Model (MongoDB)

models/Story.ts

const StorySchema = new Schema(
  {
    wallet: { type: String, index: true },
    title: String,
    story: String,
    imageUrl: String,
    tokenId: String,
    chainId: Number,
    contract: String,
    txHash: String,
    ipfsCid: String,
    public: { type: Boolean, default: true },
    likes: { type: Number, default: 0 },
    comments: [
      {
        wallet: String,
        text: String,
        createdAt: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true },
)

export default models.Story || mongoose.model("Story", StorySchema);

2
) API Routes

Fetch
global
feed
— app/api/stories/route.ts

import { NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Story from "@/models/Story"

export async function GET() {
  await dbConnect()
  const stories = await Story.find({ public: true }).sort({ createdAt: -1 }).limit(50)
  return NextResponse.json({ stories })
}

Like
a
story
— app/api/stories/like/route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Story from "@/models/Story"

export async function POST(req: NextRequest) {
  await dbConnect()
  const { id } = await req.json()
  if (!id) return NextResponse.json({ error: "Missing ID" }, { status: 400 })
  await Story.findByIdAndUpdate(id, { $inc: { likes: 1 } })
  return NextResponse.json({ ok: true })
}

Add
comment
— app/api/stories/comment/route.ts

import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Story from "@/models/Story"

export async function POST(req: NextRequest) {
  await dbConnect()
  const { id, wallet, text } = await req.json()
  if (!id || !wallet || !text) return NextResponse.json({ error: "Missing data" }, { status: 400 })
  await Story.findByIdAndUpdate(id, { $push: { comments: { wallet, text } } })
  return NextResponse.json({ ok: true })
}

3
) Global Feed Page

app/feed/page.tsx

'use client'
import { useEffect, useState } from "react"

export default function FeedPage() {
  const [stories, setStories] = useState([]);

  useEffect(() => {
    fetch("/api/stories")
      .then(r => r.json())
      .then(data => setStories(data.stories || []));
  }, []);

  const like = async (id: string) => {
    await fetch("/api/stories/like", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id })
    });
    setStories(s => s.map(st => st._id === id ? { ...st, likes: st.likes + 1 } : st));
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold text-pink-700 mb-6">💞 Love Stories Feed</h1>
      <div className="grid gap-6">
        {stories.map((st: any) => (
          <div key={st._id} className="bg-white rounded-xl shadow p-4">
            <div className="flex gap-4">
              <img src={st.imageUrl} className="w-32 h-32 rounded-lg object-cover" />
              <div>
                <h2 className="text-xl font-bold">{st.title}</h2>
                <p className="text-gray-600 text-sm mt-1">By {st.wallet.slice(0,6)}…{st.wallet.slice(-4)}</p>
                <p className="mt-2 text-sm">{st.story.slice(0,180)}...</p>
                <div className="mt-4 flex items-center gap-3">
                  <button onClick={() => like(st._id)} className="text-pink-600">❤️ {st.likes}</button>
                  <a href={`/story/${st._id}`} className="text-blue-600 text-sm">Read More →</a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

4
) Public Profile Page

app/profile/[wallet]/page.tsx

'use client'
import { useEffect, useState } from "react"
import { useParams } from "next/navigation"

export default function PublicProfile() {
  const { wallet } = useParams();
  const [stories, setStories] = useState([]);
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    fetch(`/api/profile?wallet=${wallet}`)
      .then(r => r.json())
      .then(data => setProfile(data.profile || null));
    fetch(`/api/stories?wallet=${wallet}`)
      .then(r => r.json())
      .then(data => setStories(data.stories || []));
  }, [wallet]);

  if (!profile) return <div>Loading...</div>;

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex items-center gap-6">
        <img src={stories[0]?.imageUrl || "/default-avatar.png"} className="w-32 h-32 rounded-full object-cover" />
        <div>
          <h1 className="text-3xl font-bold">{profile.name1} ❤️ {profile.name2}</h1>
          <p className="text-gray-600">Anniversary: {profile.anniversaryISO}</p>
        </div>
      </div>
      <h2 className="text-2xl font-bold mt-8">Their Stories</h2>
      <div className="grid gap-6 mt-4">
        {stories.map((st: any) => (
          <div key={st._id} className="bg-white rounded-xl shadow p-4">
            <h3 className="text-lg font-bold">{st.title}</h3>
            <p className="text-sm mt-1">{st.story.slice(0,200)}...</p>
            <a href={`/story/${st._id}`} className="text-blue-600 text-sm mt-2 inline-block">Read More →</a>
          </div>
        ))}
      </div>
    </div>
  );
}

5
) Next Steps

Add opt-in privacy toggle in profile to hide from public feed.

Support on-chain comments/likes (as NFT metadata or via Lens/Farcaster).

Use IPFS gateway URLs
for story text & images to keep
on - chain
data
light.

✅ Now we have:

Public profiles
for couples.

Global feed of love
stories.Likes / comments
stored
off - chain(fast).Ready
for later integration into Lens/Farcaster.

If
you
want, the
next
step
could
be
adding
social
login(Lens / Farcaster) + follower - only
DMs
so
couples / friends
can
interact
directly in (-app.Do)
you
want
me
to
proceed
with that?

You said
:
Sure 
ChatGPT said:
Thought
for 12s

Perfect—let
’s ship the next
module.

💬 Step 9: Lens/Farcaster login, follower-only DMs, social links & stats, + DM rewards

We’ll:

add social handles to profiles,

let users
sign in
with Farcaster or
Lens (alongside wallet),

enforce
follower - only
DMs, show
social
stats, reward
followers
who
DM.

1
) Dependencies & env
npm i jsonwebtoken zod rate-limiter-flexible


.env (add)

NEYNAR_API_KEY=...
LENSPRO_API_KEY=...          # or use public GraphQL endpoint
if preferred
JWT_SECRET=superlongrandom

2
) Extend the Couple model (social links & cached stats)

models/Couple.ts

// ...existing imports
const CoupleSchema = new Schema(
  {
    wallet: { type: String, index: true },
    email: String,
    name1: String,
    name2: String,
    anniversaryISO: { type: String, required: true },
    birthday1ISO: String,
    birthday2ISO: String,
    storyCid: String,
    imageCid: String,
    chainId: Number,
    contract: String,
    tokenId: String,
    xp: { type: Number, default: 0 },
    referralCode: { type: String, unique: true, sparse: true },
    referredBy: String,

    // NEW:
    social: {
      farcaster: { handle: String, fid: Number },
      lens: { handle: String, profileId: String },
      links: {
        x: String,
        instagram: String,
        youtube: String,
        website: String,
      },
    },
    socialStats: {
      farcasterFollowers: { type: Number, default: 0 },
      lensFollowers: { type: Number, default: 0 },
    },
  },
  { timestamps: true },
)

3
) Social connect & stats sync APIs
A) Save handles (POST /api/social/connect)
// app/api/social/connect/route.ts
import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Couple from "@/models/Couple"
import { z } from "zod"

const Body = z.object({
  wallet: z.string(),
  farcaster: z.object({ handle: z.string().optional(), fid: z.number().optional() }).optional(),
  lens: z.object({ handle: z.string().optional(), profileId: z.string().optional() }).optional(),
  links: z
    .object({
      x: z.string().optional(),
      instagram: z.string().optional(),
      youtube: z.string().optional(),
      website: z.string().optional(),
    })
    .optional(),
})

export async function POST(req: NextRequest) {
  await dbConnect()
  const body = Body.parse(await req.json())
  const doc = await Couple.findOneAndUpdate(
    { wallet: body.wallet.toLowerCase() },
    { $set: { "social.farcaster": body.farcaster, "social.lens": body.lens, "social.links": body.links } },
    { upsert: true, new: true },
  )
  return NextResponse.json({ ok: true, profile: doc })
}

B
) Pull follower counts (POST /api/social/sync)
// app/api/social/sync/route.ts
import { type NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Couple from "@/models/Couple"

async function getFarcasterFollowers(fid?: number) {
  if (!fid) return 0
  const res = await fetch("https://api.neynar.com/v2/farcaster/user?fid=" + fid, {
    headers: { api_key: process.env.NEYNAR_API_KEY! },
  })
  if (!res.ok) return 0
  const j = await res.json()
  return j?.user?.follower_count ?? 0
}
async function getLensFollowers(profileId?: string) {
  if (!profileId) return 0
  // Use Lens API / GraphQL of your choice. Placeholder below:
  const res = await fetch("https://api.lens.xyz/users/" + profileId, {
    headers: { Authorization: `Bearer ${process.env.LENSPRO_API_KEY ?? ""}` },
  }).catch(() => null as any)
  if (!res?.ok) return 0
  const j = await res.json()
  return j?.stats?.followers ?? 0
}

export async function POST(req: NextRequest) {
  await dbConnect()
  const { wallet } = await req.json()
  const doc = await Couple.findOne({ wallet: wallet.toLowerCase() })
  if (!doc) return NextResponse.json({ error: "not found" }, { status: 404 })

  const [fc, ln] = await Promise.all([
    getFarcasterFollowers(doc.social?.farcaster?.fid),
    getLensFollowers(doc.social?.lens?.profileId),
  ])

  doc.socialStats = { farcasterFollowers: fc, lensFollowers: ln }
  await doc.save()

  return NextResponse.json({ ok: true, socialStats: doc.socialStats })
}

4
) Follower-only DM checks

We’ll verify sender follows recipient on at least one network (Farcaster or Lens).
Add helper follower checks:

lib/social.ts

export async function isFarcasterFollower(followerFid: number, targetFid: number) {
  if (!followerFid || !targetFid) return false
  const url = `https://api.neynar.com/v2/farcaster/relationships?fid=${followerFid}&target_fid=${targetFid}`
  const r = await fetch(url, { headers: { api_key: process.env.NEYNAR_API_KEY! } })
  if (!r.ok) return false
  const j = await r.json()
  return Boolean(j?.relationships?.[0]?.follows)
}
export async function isLensFollower(followerProfileId: string, targetProfileId: string) {
  if (!followerProfileId || !targetProfileId) return false
  // Placeholder: call Lens GraphQL to check following;
  // return true/false from the response.
  return false
}

5
) Messages model & follower-only DM API

models/Message.ts

import mongoose, { Schema, models } from "mongoose"

const MessageSchema = new Schema(
  {
    from: { type: String, index: true },
    to: { type: String, index: true },
    text: String,
    meta: { platform: String }, // "farcaster" | "lens" | "wallet"
  },
  { timestamps: true },
)

export default models.Message || mongoose.model("Message", MessageSchema);

app / api / dm / send / route.ts

import { NextRequest, NextResponse } from "next/server"
import dbConnect from "@/lib/db"
import Couple from "@/models/Couple"
import Message from "@/models/Message"
import Reward from "@/models/Reward"
import { isFarcasterFollower, isLensFollower } from "@/lib/social"
import { randomBytes } from "crypto"
import { parseEther } from "viem"
import { RateLimiterMemory } from "rate-limiter-flexible"

const DM_REWARD = parseEther("2").toString() // 2 HEART for qualifying DM
const limiter = new RateLimiterMemory({ points: 5, duration: 60 }) // 5 DMs/min per wallet

export async function POST(req: NextRequest) {
  await dbConnect()
  const { from, to, text } = await req.json()
  if (!from || !to || !text) return NextResponse.json({ error: "missing" }, { status: 400 })
  try {
    await limiter.consume(from)
  } catch {
    return NextResponse.json({ error: "rate_limited" }, { status: 429 })
  }

  const sender = await Couple.findOne({ wallet: from.toLowerCase() })
  const receiver = await Couple.findOne({ wallet: to.toLowerCase() })
  if (!receiver) return NextResponse.json({ error: "receiver_not_found" }, { status: 404 })

  // follower check on either network
  const okFarcaster = await isFarcasterFollower(sender?.social?.farcaster?.fid!, receiver?.social?.farcaster?.fid!)
  const okLens = await isLensFollower(sender?.social?.lens?.profileId!, receiver?.social?.lens?.profileId!)
  if (!okFarcaster && !okLens) {
    return NextResponse.json({ error: "not_a_follower" }, { status: 403 })
  }

  await Message.create({
    from: from.toLowerCase(),
    to: to.toLowerCase(),
    text,
    meta: { platform: okFarcaster ? "farcaster" : "lens" },
  })

  // Issue a reward voucher once per sender->receiver per day
  const dayKey = new Date().toISOString().slice(0, 10)
  const uniqueNonce = `dm-${from.toLowerCase()}-${to.toLowerCase()}-${dayKey}-${randomBytes(6).toString("hex")}`
  await Reward.create({ wallet: from.toLowerCase(), type: "social_dm", amount: DM_REWARD, nonce: uniqueNonce })

  return NextResponse.json({ ok: true, rewarded: true })
}

This
ties
into
your
existing
voucher - based
$HEART
claim
flow
—no new on-chain code required.

6) Simple DM UI

app/dm/[wallet]/page.tsx

'use client'
import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import { useAccount } from "wagmi"

export default function DMPage() {
  const { wallet: to } = useParams();
  const { address: from } = useAccount();
  const [text, setText] = useState("");
  const [status, setStatus] = useState("");

  const send = async () => {
    setStatus("Sending…");
    const r = await fetch("/api/dm/send", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ from, to, text })
    });
    const j = await r.json();
    setStatus(j.error ? `Error: ${j.error}` : "Sent! (If you follow them, you got a reward 🎉)");
    if (!j.error) setText("");
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white rounded-2xl shadow">
      <h1 className="text-2xl font-bold text-pink-700">✉️ Message {String(to).slice(0,6)}…{String(to).slice(-4)}</h1>
      <textarea className="w-full mt-4 border rounded p-3" rows={5} value={text} onChange={(e)=>setText(e.target.value)} placeholder="Say something sweet…" />
      <button onClick={send} className="mt-4 bg-pink-600 text-white px-6 py-3 rounded-lg">Send DM</button>
      <div className="mt-2 text-sm">{status}</div>
    </div>
  );
}

7
) Show social links & stats on profile page

In your public and private profile UIs, add:

{
  /* Social links */
}
;<div className="flex gap-4 mt-3 text-sm">
  {profile?.social?.farcaster?.handle && (
    <a className="underline" href={`https://warpcast.com/${profile.social.farcaster.handle}`}>
      Farcaster @{profile.social.farcaster.handle}
    </a>
  )}
  {profile?.social?.lens?.handle && (
    <a className="underline" href={`https://hey.xyz/u/${profile.social.lens.handle}`}>
      Lens @{profile.social.lens.handle}
    </a>
  )}
  {profile?.social?.links?.x && (
    <a className="underline" href={`https://x.com/${profile.social.links.x}`}>
      X
    </a>
  )}
  {profile?.social?.links?.instagram && (
    <a className="underline" href={`https://instagram.com/${profile.social.links.instagram}`}>
      Instagram
    </a>
  )}
  {profile?.social?.links?.website && (
    <a className="underline" href={profile.social.links.website}>
      Website
    </a>
  )}
</div>

{
  /* Stats */
}
;<div className="mt-2 text-gray-600 text-sm">
  Farcaster followers: {profile?.socialStats?.farcasterFollowers ?? 0} · Lens followers:{" "}
  {profile?.socialStats?.lensFollowers ?? 0}
</div>

Add
a
“Sync stats” button (calls /api/social/sync).

8) Optional: Unified sign-in tokens (JWT)

If you want app-level sessions (
for non-wallet users)
, issue a short-lived JWT when Farcaster/Lens logins succeed, store the associated wallet
for rewards later. (You can integrate a provider like Privy to simplify Farcaster + wallet auth.)

9) Abuse & security
notes

DM
rate
limit
already
added(5 / min).Consider
per - day
caps
too.Sanitize
DM
text
optionally
run
toxicity
filters.Only
reward
unique
sender
→receiver messages per day to reduce farming.

Cache follower checks
for 10–30 minutes
to
reduce
API
costs.

✅ Delivered in this step

Social handles + stats on profiles

Follower-only DM flow

“Message-to-earn” reward issuance hooked into your existing voucher claim

Minimal UIs
for connect, sync, DM

Next up (Step 10 ideas)

Streaks + badges (DM streaks, anniversary streaks)
with on-chain badge
NFT.Referral
leaderboard + public
rankings
upgrades.One - click
“Anniversary Gift Box” mint (themed templates + fee split
with referrer)
.

Tell me “Next” and I’ll proceed
with Streaks + Badges (on-chain badge NFT) by
default.

You said:
Next 
ChatGPT said:

Boom—
let
’s ship the milestone system.

🏅 Step 10: Streaks & Badges (on-chain soulbound badges)

We’ll track daily streaks (anniversary check-ins, DMs, mints), award XP, and mint non-transferable (soulbound) badge NFTs when users hit milestones.

A) Badge design

Badge types (examples)

1001 – 7-Day Love Streak

1002 – 30-Day Love Streak

1003 – 100-Day Love Streak

1101 – First Mint

1102 – 5 Mints

1201 – 10 Follower-Only DMs

1301 – Anniversary Legend (minted on anniversary day)

Use ERC-1155
for cheap minting per badge
type.B
) Solidity: Soulbound ERC-1155 + signed mint

contracts/Badges.sol

// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20

import { ERC1155 } from "@openzeppelin/contracts/token/ERC1155/ERC1155.sol"
import { AccessControl } from "@openzeppelin/contracts/access/AccessControl.sol"

contract
Badges
is
ERC1155, AccessControl
{
  using Strings
  for uint256;

    bytes32 public constant
  ADMIN_ROLE = keccak256("ADMIN_ROLE")
  address
  public
  signer // backend signer (same pattern as Rewarder)

  // replay protection per (to, badgeId, nonceHash)
  mapping((bytes32) => bool)
  public
  used

  string
  private
  _baseURI

  event
  Minted(address indexed to, uint256 indexed id, uint256 amount, bytes32 nonce);

  constructor(string memory baseUri, address admin, address initialSigner)
  ERC1155("")
  _baseURI = baseUri
  _grantRole(DEFAULT_ADMIN_ROLE, admin)
  _grantRole(ADMIN_ROLE, admin)
  signer = initialSigner

  function setBaseURI(string memory baseUri)
  external
  onlyRole(ADMIN_ROLE)
  _baseURI = baseUri
  function setSigner(address s)
  external
  onlyRole(ADMIN_ROLE)
  signer = s

  function uri(uint256 id)
  public
  view
  override
  returns (string memory)
  return string(abi.encodePacked(_baseURI, id.toString(), ".json"));

  // Soulbound: block transfers but allow mint & burn by owner
  function _beforeTokenTransfer(address operator, address from, address to, uint256[] memory ids,
        uint256[] memory amounts, bytes memory data)
  internal
  override
  super._beforeTokenTransfer(operator, from, to, ids, amounts, data)
  // allow mint (from=0) and burn (to=0). Block regular transfers.
  if (from != address(0) && to != address(0)) {
    revert("Soulbound")
  }

  // Claim with EIP-191 compatible signature:
  // hash = keccak256("BADGE(", to, id, amount, nonce, rewarder)") then personal_sign
  function claim(address to, uint256 id, uint256 amount, bytes32 nonce, bytes calldata sig)
  external
  bytes32
  inner = keccak256(abi.encodePacked("BADGE(", to, id, amount, nonce, address(this), ")"))
  bytes32
  digest = keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", inner))
    (bytes32
    r, bytes32
    s, uint8
    v
    ) = _split(sig)
  address
  recovered = ecrecover(digest, v, r, s)
  require(recovered == signer, "bad sig")

  bytes32
  key = keccak256(abi.encodePacked(to, id, nonce))
  require(!used[key], "nonce used")
  used[key] = true

  _mint(to, id, amount, "")
  emit
  Minted(to, id, nonce)

  function burn(uint256 id, uint256 amount)
  external
  _burn(msg.sender, id, amount)

  function _split(bytes memory sig)
  internal
  pure
  returns (bytes32 r, bytes32 s, uint8 v)
  require(sig.length == 65, "bad sig len")
  assembly
  r :
  = mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
}

Deploy
flow

Deploy
Badges(baseUri, adminEOA, backendSignerEOA).Host
badge
metadata
at
baseUri /
  <id>.json (IPFS or https).

C) Server: streak tracking & badge/XP awarding
1) Models

models/Streak.ts

import mongoose, { Schema, models } from "mongoose";

const StreakSchema = new Schema({
  wallet: { type: String, index: true },
  type: { type: String, enum: ["love","dm","mint"], index: true }, // per-category
  lastDayISO: String,            // "YYYY-MM-DD"
  count: { type: Number, default: 0 } // current streak
}, { timestamps: true });

export default models.Streak || mongoose.model("Streak", StreakSchema);


models/BadgeAward.ts

import mongoose, { Schema, models } from "mongoose";

const BadgeAwardSchema = new Schema({
  wallet: { type: String, index: true },
  badgeId: Number,
  nonce: { type: String, unique: true, index: true },
  minted: { type: Boolean, default: false }
}, { timestamps: true });

export default models.BadgeAward || mongoose.model("BadgeAward", BadgeAwardSchema);


You already have Reward for $HEART; we’ll also issue HEART with certain badges.

2) Utilities

lib/dates.ts

export function todayISO(tzOffsetMinutes = 0) {
  const now = new Date();
  const tz = new Date(now.getTime() + tzOffsetMinutes*60000);
  return tz.toISOString().slice(0,10);
}
export function nextISO(dateISO: string) {
  const [y,m,d] = dateISO.split("-").map(Number);
  const dt = new Date(y, m-1, d+1);
  return dt.toISOString().slice(0,10);
}

3) Increment streak API (called on qualifying actions)

Qualifying actions:

Love streak: visiting /profile and clicking “Check-in Today”, or auto on anniversary day.

DM streak: sending a valid follower-only DM (/api/dm/send already exists) → call increment.

Mint streak: minting at least one story that day.

lib/streak.ts

import Streak from "@/models/Streak";
import { todayISO } from "./dates";

export async function bumpStreak(wallet: string, type: "love"|"dm"|"mint", tzOffsetMin = 330) {
  const today = todayISO(tzOffsetMin);
  const s = await Streak.findOne({ wallet: wallet.toLowerCase(), type });
  if (!s) return Streak.create({ wallet: wallet.toLowerCase(), type, lastDayISO: today, count: 1 });

  if (s.lastDayISO === today) return s;                 // already counted today
  const yesterday = new Date(); yesterday.setDate(yesterday.getDate()-1);
  const yISO = yesterday.toISOString().slice(0,10);
  const nextCount = (s.lastDayISO === yISO) ? s.count + 1 : 1;
  s.count = nextCount; s.lastDayISO = today;
  await s.save();
  return s;
}

4) Award logic (create badge voucher + optional HEART reward)

app/api/streak/check-awards/route.ts

import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import Streak from "@/models/Streak";
import BadgeAward from "@/models/BadgeAward";
import Reward from "@/models/Reward";
import { randomBytes } from "crypto";
import { parseEther } from "viem";

const HEART_FOR_7 = parseEther("10").toString();
const HEART_FOR_30 = parseEther("30").toString();
const HEART_FOR_100 = parseEther("100").toString();

const BADGE_MAP: Record<string, { [k: number]: number }> = {
  love: { 7: 1001, 30: 1002, 100: 1003 },
  mint: { 1: 1101, 5: 1102 },
  dm: { 10: 1201 }
};

export async function POST(req: NextRequest) {
  await dbConnect();
  const { wallet, type } = await req.json();
  const s = await Streak.findOne({ wallet: wallet.toLowerCase(), type });
  if (!s) return NextResponse.json({ ok: true, awarded: [] });

  const thresholds = BADGE_MAP[type] || {};
  const justHit = Object.keys(thresholds).map(Number).filter(n => n === s.count);

  const awarded: number[] = [];
  for (const n of justHit) {
    const badgeId = thresholds[n];
    const nonce = `badge-${wallet.toLowerCase()}-${badgeId}-${randomBytes(8).toString("hex")}`;
    await BadgeAward.create({ wallet: wallet.toLowerCase(), badgeId, nonce });

    // Optional HEART reward
    if (badgeId === 1001) await Reward.create({ wallet: wallet.toLowerCase(), type: "badge_7", amount: HEART_FOR_7, nonce: `heart7-${randomBytes(8).toString("hex")}` });
    if (badgeId === 1002) await Reward.create({ wallet: wallet.toLowerCase(), type: "badge_30", amount: HEART_FOR_30, nonce: `heart30-${randomBytes(8).toString("hex")}` });
    if (badgeId === 1003) await Reward.create({ wallet: wallet.toLowerCase(), type: "badge_100", amount: HEART_FOR_100, nonce: `heart100-${randomBytes(8).toString("hex")}` });

    awarded.push(badgeId);
  }

  return NextResponse.json({ ok: true, awarded });
}

5) Issue badge voucher signature (similar to rewards flow)

lib/signBadge.ts

import { encodePacked, keccak256, toBytes, privateKeyToAccount } from "viem";

const account = privateKeyToAccount(process.env.BACKEND_SIGNER_PK as `0x${string}`);

export async function signBadge({ to, id, amount, badgeAddr }: { to: `0x${string}`, id: number, amount: number, badgeAddr: `0x${string}` }) {
  const inner = keccak256(encodePacked(["string","address","uint256","uint256","bytes32","address"],
    ["BADGE(", to, BigInt(id), BigInt(amount), keccak256(toBytes("nonce")), badgeAddr])); // nonce handled in route
  // We’ll actually sign the exact inner constructed with the real nonce in route (see below).
  return account; // returning signer for reuse — actual signing in route
}


app/api/badges/voucher/route.ts

import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import BadgeAward from "@/models/BadgeAward";
import { privateKeyToAccount } from "viem/accounts";
import { encodePacked, keccak256, toBytes } from "viem";

const BADGES_ADDRESS = process.env.BADGES_ADDRESS as `0x${string}`;
const signer = privateKeyToAccount(process.env.BACKEND_SIGNER_PK as `0x${string}`);

export async function POST(req: NextRequest) {
  await dbConnect();
  const { wallet } = await req.json();
  const award = await BadgeAward.findOne({ wallet: wallet.toLowerCase(), minted: false }).sort({ createdAt: 1 });
  if (!award) return NextResponse.json({ none: true });

  const inner = keccak256(encodePacked(
    ["string","address","uint256","uint256","bytes32","address"],
    ["BADGE(", wallet, BigInt(award.badgeId), BigInt(1), keccak256(toBytes(award.nonce)), BADGES_ADDRESS]
  ));
  const sig = await signer.signMessage({ message: { raw: toBytes(inner) } });

  return NextResponse.json({
    voucher: {
      to: wallet,
      id: award.badgeId,
      amount: "1",
      nonce: award.nonce,
      signature: sig,
      badge: BADGES_ADDRESS
    }
  });
}


app/api/badges/minted/route.ts

import { NextRequest, NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import BadgeAward from "@/models/BadgeAward";

export async function POST(req: NextRequest) {
  await dbConnect();
  const { nonce } = await req.json();
  await BadgeAward.updateOne({ nonce }, { $set: { minted: true } });
  return NextResponse.json({ ok: true });
}

D) Frontend widgets
1) Streak panel (add to profile)
'use client';
import { useEffect, useState } from "react";
import { useAccount } from "wagmi";

export function StreakPanel({ type = "love" }: { type?: "love"|"dm"|"mint" }) {
  const { address } = useAccount();
  const [count, setCount] = useState(0);
  const [awarded, setAwarded] = useState<number[]>([]);

  const checkIn = async () => {
    await fetch("/api/streak/bump", { // you can expose an endpoint that calls bumpStreak then check-awards
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ wallet: address, type })
    });
    const r = await fetch("/api/streak/check-awards", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ wallet: address, type })
    });
    const j = await r.json();
    setAwarded(j.awarded || []);
    refresh();
  };

  const refresh = async () => {
    const r = await fetch(`/api/streak/get?wallet=${address}&type=${type}`);
    const j = await r.json();
    setCount(j.count || 0);
  };

  useEffect(()=>{ if(address) refresh(); }, [address]);

  return (
    <div className="p-4 bg-white rounded-xl shadow">
      <div className="font-bold text-pink-700">🔥 {type.toUpperCase()} Streak: {count} day(s)</div>
      <button onClick={checkIn} className="mt-3 bg-pink-600 text-white px-4 py-2 rounded-lg">Check-in Today</button>
      {awarded.length>0 && <div className="mt-2 text-sm">🏅 New badges: {awarded.join(", ")}</div>}
    </div>
  );
}


(Implement /api/streak/get + /api/streak/bump thin wrappers that call your bumpStreak util.)

2) “Claim Badge” button
'use client';
import { useState } from "react";
import { ethers } from "ethers";
import { useAccount } from "wagmi";

export function ClaimBadge() {
  const { address } = useAccount();
  const [status, setStatus] = useState("");

  const claim = async () => {
    setStatus("Fetching voucher…");
    const r = await fetch("/api/badges/voucher", {
      method: "POST", headers: { "Content-Type":"application/json" },
      body: JSON.stringify({ wallet: address })
    });
    const j = await r.json();
    if (j.none) return setStatus("No badges to claim.");
    const v = j.voucher;

    const provider = new ethers.BrowserProvider((window as any).ethereum);
    const signer = await provider.getSigner();
    const c = new ethers.Contract(v.badge, [
      "function claim(address to,uint256 id,uint256 amount,bytes32 nonce,bytes sig) external"
    ], signer);

    const nonce32 = ethers.id(v.nonce);
    setStatus("Minting badge on-chain…");
    const tx = await c.claim(address, v.id, v.amount, nonce32, v.signature);
    await tx.wait();

    await fetch("/api/badges/minted", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ nonce: v.nonce })});
    setStatus("Badge minted! 🎉");
  };

  return (
    <div className="p-4 bg-white rounded-xl shadow">
      <button onClick={claim} className="bg-pink-600 text-white px-4 py-2 rounded-lg">Claim Badge</button>
      <div className="text-sm mt-2">{status}</div>
    </div>
  );
}

E) Metadata & art

Host badge art & metadata at ipfs://.../1001.json, etc.
Example 1001.json:

{
  "name": "7-Day Love Streak",
  "description": "Awarded for reaching a 7-day love streak on MetaLove Vault.",
  "image": "ipfs://.../1001.png",
  "attributes": [{"trait_type":"Category","value":"Streak"},{"trait_type":"Days","value":7}]
}

F) Env vars to add
BADGES_ADDRESS=0x...          # deployed Badges
BACKEND_SIGNER_PK=0x...       # signer that Badges recognizes

G) How it all ties together

User performs an action → your code calls bumpStreak(wallet, type).

Immediately call /api/streak/check-awards → creates BadgeAward rows (+ optional HEART Reward rows).

User goes to Claim Badge → server returns a signed voucher → user mints on-chain via Badges.claim.

HEART rewards still claimed via your existing Rewarder flow.

✅ Delivered in this step

Soulbound badge contract (ERC-1155, signed claims).

Streak tracking models + utils + award logic.

“Claim Badge” mint flow.

UX widgets for streaks & claiming.

Want me to package all steps into a clean repo structure (folders, pages, contracts, scripts) next, or add a themed Anniversary Gift Box mint with split fees to referrers?

You said:
Sure 
ChatGPT said:

Sweet — I’ll package everything into a clean, production-ready repo layout so you can clone, fill in envs, and run.

📦 MetaLove Vault — Monorepo Layout
metalove-vault/
├─ apps/
│  └─ web/                      # Next.js 14 (App Router)
│     ├─ app/
│     │  ├─ api/                # All REST routes
│     │  │  ├─ badges/
│     │  │  │  ├─ minted/route.ts
│     │  │  │  └─ voucher/route.ts
│     │  │  ├─ dm/send/route.ts
│     │  │  ├─ generate-portrait/route.ts
│     │  │  ├─ generate-story/route.ts
│     │  │  ├─ leaderboard/route.ts
│     │  │  ├─ pay-access/route.ts
│     │  │  ├─ profile/route.ts
│     │  │  ├─ referral/attach/route.ts
│     │  │  ├─ rewards/claimed/route.ts
│     │  │  ├─ rewards/voucher/route.ts
│     │  │  ├─ social/connect/route.ts
│     │  │  ├─ social/sync/route.ts
│     │  │  ├─ stories/route.ts
│     │  │  ├─ stories/comment/route.ts
│     │  │  ├─ stories/like/route.ts
│     │  │  ├─ streak/bump/route.ts
│     │  │  ├─ streak/check-awards/route.ts
│     │  │  └─ streak/get/route.ts
│     │  ├─ (public)/
│     │  │  ├─ page.tsx                # Landing
│     │  │  ├─ feed/page.tsx
│     │  │  ├─ profile/[wallet]/page.tsx
│     │  │  ├─ story/[id]/page.tsx     # (optional detail page)
│     │  ├─ mint/page.tsx
│     │  ├─ portrait/page.tsx
│     │  ├─ profile/page.tsx           # Private profile (connected wallet)
│     │  ├─ rewards/page.tsx
│     │  ├─ dm/[wallet]/page.tsx
│     │  ├─ deploy/page.tsx            # Gated page (NFT or fee)
│     │  └─ layout.tsx                 # Wagmi/RainbowKit/Thirdweb providers
│     ├─ components/
│     │  ├─ ClaimBadge.tsx
│     │  ├─ Leaderboard.tsx
│     │  ├─ NFTGate.tsx
│     │  ├─ PaywallButton.tsx
│     │  └─ StreakPanel.tsx
│     ├─ lib/
│     │  ├─ db.ts
│     │  ├─ dates.ts
│     │  ├─ sign.ts
│     │  ├─ signBadge.ts
│     │  ├─ social.ts
│     │  └─ streak.ts
│     ├─ models/
│     │  ├─ AccessPass.ts
│     │  ├─ BadgeAward.ts
│     │  ├─ Couple.ts
│     │  ├─ Message.ts
│     │  ├─ Referral.ts
│     │  ├─ Reward.ts
│     │  └─ Story.ts
│     ├─ public/
│     │  └─ default-avatar.png
│     ├─ styles/
│     │  └─ globals.css
│     ├─ next.config.mjs
│     ├─ package.json
│     └─ tsconfig.json
├─ contracts/
│  ├─ HeartToken.sol
│  ├─ Rewarder.sol
│  ├─ Badges.sol
│  ├─ scripts/
│  │  ├─ deploy_heart_rewarder.ts
│  │  └─ deploy_badges.ts
│  ├─ foundry.toml
│  └─ package.json                  # if using hardhat, include hardhat.config.ts instead
├─ metadata/
│  └─ badges/
│     ├─ 1001.json  # 7-Day Love Streak
│     ├─ 1002.json  # 30-Day Love Streak
│     ├─ 1003.json  # 100-Day Love Streak
│     ├─ 1101.json  # First Mint
│     ├─ 1102.json  # 5 Mints
│     └─ 1201.json  # 10 Follower-Only DMs
├─ .env.example
├─ README.md
└─ turbo.json (optional, for Turborepo)

⚙️ Key Config Snippets
apps/web/app/layout.tsx (providers)

Use Wagmi + RainbowKit + Thirdweb in one place.

"use client";
import "@rainbow-me/rainbowkit/styles.css";
import { RainbowKitProvider, getDefaultWallets } from "@rainbow-me/rainbowkit";
import { WagmiConfig, configureChains, createConfig } from "wagmi";
import { base, polygon, mainnet } from "wagmi/chains";
import { publicProvider } from "wagmi/providers/public";
import { ThirdwebProvider } from "@thirdweb-dev/react";

const { chains, publicClient } = configureChains([base, polygon, mainnet], [publicProvider()]);
const { connectors } = getDefaultWallets({ appName: "MetaLove Vault", projectId: process.env.NEXT_PUBLIC_WALLETCONNECT_ID!, chains });
const wagmiConfig = createConfig({ autoConnect: true, connectors, publicClient });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en"><body>
      <WagmiConfig config={wagmiConfig}>
        <RainbowKitProvider chains={chains}>
          <ThirdwebProvider activeChain={base} clientId={process.env.NEXT_PUBLIC_THIRDWEB_CLIENT_ID}>
            {children}
          </ThirdwebProvider>
        </RainbowKitProvider>
      </WagmiConfig>
    </body></html>
  );
}

.env.example
# Web
NEXT_PUBLIC_THIRDWEB_CLIENT_ID=
NEXT_PUBLIC_WALLETCONNECT_ID=
MONGODB_URI=
OPENAI_API_KEY=
REPLICATE_API_TOKEN=
NEYNAR_API_KEY=
LENSPRO_API_KEY=
JWT_SECRET=

# Contracts / On-chain
REWARDER_ADDRESS=
BADGES_ADDRESS=
BACKEND_SIGNER_PK=0x...

# Optional email/push
RESEND_API_KEY=

🧪 Local Dev
# 1) install
pnpm i    # or npm/yarn

# 2) env
cp .env.example apps/web/.env.local
# fill values

# 3) run web
cd apps/web && pnpm dev


Recommended testnet: Base Sepolia (cheap, active).

🧱 Contracts — deploy with Foundry (or Hardhat)

Foundry quickstart

cd contracts
forge install OpenZeppelin/openzeppelin-contracts
forge build


Example deploy script (Foundry / TS Runner) — scripts/deploy_heart_rewarder.ts

import { ethers } from "ethers";
import fs from "fs";

async function main() {
  const rpc = process.env.RPC!;
  const pk = process.env.DEPLOYER_PK!;
  const signer = new ethers.Wallet(pk, new ethers.JsonRpcProvider(rpc));

  // compile artifacts (if using hardhat). For Foundry, use ABI JSONs.
  const heartAbi = JSON.parse(fs.readFileSync("./out/HeartToken.sol/HeartToken.json","utf8")).abi;
  const heartBytecode = JSON.parse(fs.readFileSync("./out/HeartToken.sol/HeartToken.json","utf8")).bytecode.object;
  const rewarderAbi = JSON.parse(fs.readFileSync("./out/Rewarder.sol/Rewarder.json","utf8")).abi;
  const rewarderBytecode = JSON.parse(fs.readFileSync("./out/Rewarder.sol/Rewarder.json","utf8")).bytecode.object;

  const Heart = new ethers.ContractFactory(heartAbi, heartBytecode, signer);
  const heart = await Heart.deploy(await signer.getAddress());
  await heart.waitForDeployment();

  const Rewarder = new ethers.ContractFactory(rewarderAbi, rewarderBytecode, signer);
  const rewarder = await Rewarder.deploy(await heart.getAddress(), process.env.BACKEND_SIGNER_ADDR);
  await rewarder.waitForDeployment();

  // grant minter
  const MINTER_ROLE = ethers.id("MINTER_ROLE");
  await (await heart.grantRole(MINTER_ROLE, await rewarder.getAddress())).wait();

  console.log("Heart:", await heart.getAddress());
  console.log("Rewarder:", await rewarder.getAddress());
}
main().catch(console.error);


(Repeat similarly for Badges.sol and set BADGES_ADDRESS.)

🧩 Where to paste earlier code

Story generator: generate-story/route.ts + app/story/page.tsx

Portrait: generate-portrait/route.ts + app/portrait/page.tsx

Minting: app/mint/page.tsx + Thirdweb config in layout

Profiles/Anniversary: models/Couple.ts, profile/route.ts, anniversary/route.ts (or inside profile route), app/profile/page.tsx

Rewards/Referrals: models/Reward.ts, models/Referral.ts, rewards/*, referral/attach/route.ts, app/rewards/page.tsx

Paywall/NFTGate: components/NFTGate.tsx, components/PaywallButton.tsx, app/deploy/page.tsx

Feed: models/Story.ts, stories/*, app/feed/page.tsx, app/profile/[wallet]/page.tsx

DM + Social: models/Message.ts, social/*, dm/send, app/dm/[wallet]/page.tsx

Streaks & Badges: models/Streak.ts, models/BadgeAward.ts, streak/*, badges/*, components/StreakPanel.tsx, components/ClaimBadge.tsx

🧰 Quality-of-life scripts (package.json)

In apps/web/package.json:

{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "typecheck": "tsc --noEmit",
    "seed": "tsx scripts/seed.ts"   // optional: seeds a test user/story
  }
}


Optional scripts/seed.ts to create a dummy Couple, Story, Rewards for quick UI testing.

🔐 Security & Production Notes

Signer key (BACKEND_SIGNER_PK) should be on server-side only (Vercel env, never exposed to client).

Use a Gnosis Safe as HeartToken admin to manage minter grants safely.

Add CORS guards on APIs if you later separate domains.

Rate-limit sensitive routes (/api/dm/send, /api/rewards/voucher, /api/badges/voucher).

Add basic authZ checks: wallet address from Wagmi should match req.body.wallet (defend against spoofing).

For fee pricing in native tokens, fetch USD→native conversion server-side and cache for 60s.

🚀 Deployment

Frontend: Vercel (set envs in project settings).

DB: MongoDB Atlas.

Contracts: Base/Polygon (testnets first: Base Sepolia / Polygon Amoy).

Storage: IPFS via Thirdweb or NFT.storage for images & badge metadata.

✅ What you can do now

Create the repo with this structure.

Drop in the code we’ve built in earlier steps (it’s already segmented for these paths).

Fill .env.local, deploy contracts, set REWARDER_ADDRESS & BADGES_ADDRESS.

pnpm dev → connect wallet → generate story/portrait → mint → set profile → referrals → claim HEART → DM → streaks → claim badges.

Want me to also add a “Valentine Gift Box” one-click mint (template art + dynamic message, with fee split to referrer), or should I write a polished README.md for the repo with screenshots and quickstart?

You said:
Cool send entire project with GitHub repository zip format
ChatGPT said:
Thought for 1m 3s
Analysis paused

Attach
Voice
ChatGPT can make mistakes. Check important info.
